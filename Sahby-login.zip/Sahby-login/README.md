# صحبي — Sahby
نسخة أولى من تطبيق صحبي مع تسجيل دخول وإنشاء حساب.

## مهم قبل النشر
في Vercel أضف Environment Variable باسم `DATABASE_URL` وضع فيه **Connection String** لقاعدة Neon الخاصة بالمشروع. لا ترسل كلمة المرور هنا.

الواجهة تحتوي على تسجيل الدخول/إنشاء الحساب، وواجهات API في `/api/auth/register` و`/api/auth/login`.

بعد ربط DATABASE_URL، أول تسجيل حساب ينشئ جدول `app_users` تلقائياً إذا لم يكن موجوداً.
